module astrobee_test_ground {
	requires opencv;
	requires com.google.zxing;
}