package learn_opencv_d;
/*module learn_opencv_d {
	requires javafx.controls;
	requires javafx.fxml;
	
	opens application to javafx.graphics, javafx.fxml;
}*/
